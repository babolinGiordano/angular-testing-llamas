import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ld-llama-page',
  templateUrl: './llama-page.component.html',
  styleUrls: ['./llama-page.component.scss']
})
export class LlamaPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
