export interface Llama {
  name: string;
  imageFileName: string;
}
